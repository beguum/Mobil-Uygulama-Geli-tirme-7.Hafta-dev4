import 'package:flutter/material.dart';

void main() => runApp(KisilikAnketiApp());

class KisilikAnketiApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kişilik Anketi',
      theme: ThemeData(
        primarySwatch: Colors.orange,
      ),
      home: KisilikAnketiForm(),
    );
  }
}

class KisilikAnketiForm extends StatefulWidget {
  @override
  _KisilikAnketiFormState createState() => _KisilikAnketiFormState();
}

class _KisilikAnketiFormState extends State<KisilikAnketiForm> {
  final _formKey = GlobalKey<FormState>();
  String? _isimSoyisim;
  String? _cinsiyet;
  bool _resitMi = false;
  bool _sigaraKullaniyorMu = false;
  double _sigaraSayisi = 0;
  bool _formGonderildi = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Kişilik Anketi'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                // Ad ve Soyad
                TextFormField(
                  decoration: InputDecoration(
                    labelText: 'Adınız ve soyadınız',
                  ),
                  onSaved: (value) {
                    _isimSoyisim = value;
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Lütfen adınızı ve soyadınızı girin';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 16.0),

                // Cinsiyet seçimi
                DropdownButtonFormField<String>(
                  decoration:
                      InputDecoration(labelText: 'Cinsiyetinizi Seçiniz'),
                  items: ['Erkek', 'Kadın', 'Diğer'].map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (newValue) {
                    setState(() {
                      _cinsiyet = newValue;
                    });
                  },
                  validator: (value) {
                    if (value == null) {
                      return 'Lütfen cinsiyet seçiniz';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 16.0),

                // Reşit misiniz? (Checkbox)
                CheckboxListTile(
                  title: Text('Reşit misiniz?'),
                  value: _resitMi,
                  onChanged: (bool? value) {
                    setState(() {
                      _resitMi = value ?? false;
                    });
                  },
                ),
                SizedBox(height: 16.0),

                // Sigara Kullanımı (Switch)
                SwitchListTile(
                  title: Text('Sigara kullanıyor musunuz?'),
                  value: _sigaraKullaniyorMu,
                  onChanged: (bool value) {
                    setState(() {
                      _sigaraKullaniyorMu = value;
                    });
                  },
                ),

                // Slider (Eğer sigara içiyorsa)
                if (_sigaraKullaniyorMu) ...[
                  Text('Günde kaç sigara içiyorsunuz?'),
                  Slider(
                    value: _sigaraSayisi,
                    min: 0,
                    max: 40,
                    divisions: 40,
                    label: _sigaraSayisi.round().toString(),
                    onChanged: (double value) {
                      setState(() {
                        _sigaraSayisi = value;
                      });
                    },
                  ),
                ],

                SizedBox(height: 32.0),

                // Gönder Butonu
                Center(
                  child: ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        _formKey.currentState!.save();
                        setState(() {
                          _formGonderildi = true;
                        });
                      }
                    },
                    child: Text('Bilgilerimi gönder'),
                  ),
                ),

                SizedBox(height: 16.0),

                // Gönderildikten Sonra Bilgilerin Görüntülenmesi
                if (_formGonderildi) ...[
                  Container(
                    padding: EdgeInsets.all(16.0),
                    margin: EdgeInsets.only(top: 16.0),
                    color: Colors.orange[100],
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Ad ve Soyad: $_isimSoyisim',
                            style: TextStyle(fontSize: 16)),
                        Text('Cinsiyet: $_cinsiyet',
                            style: TextStyle(fontSize: 16)),
                        Text('Reşit misiniz: ${_resitMi ? 'Evet' : 'Hayır'}',
                            style: TextStyle(fontSize: 16)),
                        Text(
                            'Sigara kullanıyor musunuz: ${_sigaraKullaniyorMu ? 'Evet' : 'Hayır'}',
                            style: TextStyle(fontSize: 16)),
                        if (_sigaraKullaniyorMu)
                          Text(
                              'Günde içilen sigara sayısı: ${_sigaraSayisi.round()}',
                              style: TextStyle(fontSize: 16)),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
